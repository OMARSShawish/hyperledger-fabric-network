FABRIC_CFG_PATH=${PWD}/final2
networkUp(){
    DOCKER_SOCK="${DOCKER_SOCK}" docker-compose -f ${COMPOSE_FILE_BASE} up -d 2>&1
}
networkDown(){
    DOCKER_SOCK=$DOCKER_SOCK docker-compose -f $COMPOSE_FILE_BASE down --volumes --remove-orphans
}

createChannel(){
    ./createChannel.sh $CHANNEL_NAME

}


COMPOSE_FILE_BASE=docker-compose.yaml
SOCK="${DOCKER_HOST:-/var/run/docker.sock}"
DOCKER_SOCK="${SOCK##unix://}"

MODE=$1
CHANNEL_NAME=$2

if [ "$MODE" = "up" ]; then
    networkUp
elif [ "$MODE" = "createChannel" ]; then
  createChannel
elif [ "$MODE" = "down" ]; then
    networkDown
fi
