#!/bin/bash

# Source environment variables
CHANNEL_NAME=$1
source ./env.sh

# Create channel artifacts directory if it doesn't exist
if [ ! -d "channel-artifacts" ]; then
    mkdir channel-artifacts
fi

# Generate genesis block
createGenesisBlock() {
    configtxgen -profile TwoOrgsApplicationGenesis -outputBlock ./channel-artifacts/${CHANNEL_NAME}.block -channelID $CHANNEL_NAME
}

# Create channel and join ordering service node
createChannel() {
    setGlobals 1
    #: ${rc:=0}
    #: ${COUNTER:=0}

    #while [ "$rc" -ne 0 ] && [ "$COUNTER" -lt "$MAX_RETRY" ]; do
        #sleep $DELAY
    osnadmin channel join --channelID $CHANNEL_NAME --config-block ./channel-artifacts/${CHANNEL_NAME}.block -o localhost:7053 --ca-file "$ORDERER_CA" --client-cert "$ORDERER_ADMIN_TLS_SIGN_CERT" --client-key "$ORDERER_ADMIN_TLS_PRIVATE_KEY" > log.txt
        #rc=$?
        #COUNTER=$((COUNTER + 1))
    #done

    cat log.txt
}

# Join peer to the channel
joinChannel() {
    local ORG=$1
    setGlobals $ORG
    #: ${rc:=0}
    #: ${COUNTER:=0}

    #while [ "$rc" -ne 0 ] && [ "$COUNTER" -lt "$MAX_RETRY" ]; do
        #sleep $DELAY
    peer channel join -b $BLOCKFILE > log.txt
        #rc=$?
        #COUNTER=$((COUNTER + 1))
    #done

    cat log.txt
}

# Set Fabric configuration path

BLOCKFILE="./channel-artifacts/${CHANNEL_NAME}.block"

# Main execution
createGenesisBlock
createChannel
joinChannel 1
joinChannel 2
